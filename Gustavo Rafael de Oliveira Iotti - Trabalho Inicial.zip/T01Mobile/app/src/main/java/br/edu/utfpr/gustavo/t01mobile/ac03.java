package br.edu.utfpr.gustavo.t01mobile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

public class ac03 extends AppCompatActivity {

    RadioButton rbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ac03);
        Intent intent = getIntent();
        String nome = (String) intent.getSerializableExtra("Nome");
        int opcao = (Integer) intent.getSerializableExtra("Opcao");

        TextView texto = (TextView) findViewById(R.id.txtHere);

            if(opcao == 1)
            texto.setText("Parabéns " + nome);

        if(opcao == 2)

            texto.setText("Não se preocupe " + nome);


        if(opcao == 3)
        texto.setText("Que vida boa " +nome);




        if(intent.equals(1)){
            texto.setText("Parabéns" +nome);
        }
        if(intent.equals(2)){
            texto.setText("Não se preocupe" +nome);
        }
        if(intent.equals(3)){
            texto.setText("Que vida boa" +nome);
        }


    }


    public void voltar(View view){
        finish();
    }
}
