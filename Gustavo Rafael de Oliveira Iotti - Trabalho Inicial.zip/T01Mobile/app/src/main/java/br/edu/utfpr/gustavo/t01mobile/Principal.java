package br.edu.utfpr.gustavo.t01mobile;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class Principal extends AppCompatActivity {

    Button bt;
    EditText edit;
    int in;
    RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);




        final EditText n = (EditText) findViewById(R.id.txtNome);
        Button ok = (Button) findViewById(R.id.dica);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Principal.this, ac03.class);
                intent.putExtra("Nome", n.getText().toString());
                intent.putExtra("Opcao", in);
                startActivity(intent);

                SharedPreferences pre = getSharedPreferences("preferencias", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = pre.edit();

                editor.putString("Nome", n.getText().toString());
                editor.putString("Opcao", n.getText().toString());

                editor.apply();
            }
        });
        Button limpar = (Button) findViewById(R.id.clean);
        rg = (RadioGroup) findViewById(R.id.radioGroup);
        limpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                n.setText("");
                rg.clearCheck();
            }
        });



         //edit = (EditText) findViewById(R.id.txtNome);

        bt = (RadioButton) findViewById(R.id.empRb);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                in = 1;
            }
        });

       bt = (RadioButton) findViewById(R.id.desRb);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //st = "Não se preocupe" + edit.getText();
                in = 2;
            }
        });

        bt = (RadioButton) findViewById(R.id.npRb);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                in = 3;
            }
        });




    }




    public void voltar(View view){
        Intent intent3 = new Intent(getApplicationContext(),ac03.class);
        startActivity(intent3);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            Intent intent1 = new Intent(getApplicationContext(),Ac02.class);
            startActivity(intent1);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }


}
