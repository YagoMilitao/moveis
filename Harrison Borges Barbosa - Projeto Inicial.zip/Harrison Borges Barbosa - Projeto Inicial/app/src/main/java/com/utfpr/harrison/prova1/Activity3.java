package com.utfpr.harrison.prova1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Activity3 extends AppCompatActivity {

    public static final String str_nome         = "NOME";
    public static final String str_situacao     = "SITUACAO";

    private String nome;
    private Integer situacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        Button voltar = (Button) findViewById(R.id.btnVoltar);

        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Bundle extras = getIntent().getExtras();
        nome = extras.getString(str_nome);
        situacao = extras.getInt(str_situacao);

        TextView mensagem = (TextView) findViewById(R.id.txtMensagem);

        switch(situacao) {
            case 1:
                mensagem.setText("Parabéns " + nome + "!");
            break;
            case 2:
                mensagem.setText("Não se preocupe " + nome + "!");
            break;
            case 3:
                mensagem.setText("Que vida boa " + nome + "!");
            break;
            default:
                mensagem.setText("Ops, não sei o que dizer...");
            break;
        }

    }
}
