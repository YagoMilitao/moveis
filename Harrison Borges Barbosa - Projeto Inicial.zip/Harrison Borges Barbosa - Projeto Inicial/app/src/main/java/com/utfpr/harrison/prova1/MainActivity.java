package com.utfpr.amilton.prova1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    public static final String str_nome         = "NOME";
    public static final String str_situacao     = "SITUACAO";

    Button _dica;
    Button _limpar;
    EditText _nome;
    RadioGroup _situacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _dica = (Button) findViewById(R.id.btnDica);
        _limpar = (Button) findViewById(R.id.btnLimpar);
        _nome = (EditText) findViewById(R.id.editNome);
        _situacao = (RadioGroup) findViewById(R.id.btnSituacao);

        _dica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvar();

                dica();
            }
        });

        _limpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limpar();
            }
        });

        recuperar();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_ajuda, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_ajuda) {
            ajuda();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void ajuda() {
        Intent intent = new Intent(this, Activity2.class);

        startActivity(intent);
    }

    private void dica() {
        Intent intent = new Intent(this, Activity3.class);

        Bundle extras = new Bundle();
        extras.putString(str_nome, _nome.getText().toString());
        extras.putInt(str_situacao, sel_situacao(_situacao.getCheckedRadioButtonId()));

        intent.putExtras(extras);

        startActivity(intent);
    }

    private void limpar() {
        _nome.setText("");
        _situacao.clearCheck();
        _nome.requestFocus();
    }

    public int sel_situacao(int id) {
        switch(id) {
            case R.id.btnEmpregado:
                return 1;
            case R.id.btnDesempregado:
                return 2;
            case R.id.btnNaoProcuraOcupacao:
                return 3;
            default:
                return 0;
        }
    }

    public void salvar() {
        SharedPreferences.Editor editor = getSharedPreferences("PREFERENCIAS", MODE_PRIVATE).edit();
        editor.putString(str_nome, _nome.getText().toString());
        editor.putInt(str_situacao, _situacao.getCheckedRadioButtonId());
        editor.apply();
    }

    public void recuperar() {
        SharedPreferences prefs = getSharedPreferences("PREFERENCIAS", MODE_PRIVATE);
        String restoredText = prefs.getString(str_nome, null);
        if (restoredText != null) {
            _nome.setText(prefs.getString(str_nome, ""));
            _situacao.check(prefs.getInt(str_situacao, 0));
        }
    }
}
