package com.example.kamilla.trabalho;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Info extends AppCompatActivity {

    TextView recebeNome;
    Button btn3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        Intent intent = getIntent();

        recebeNome = (TextView)findViewById(R.id.mostraNome);
        String valor = (String) intent.getSerializableExtra("Nome");
        String situacao = (String) intent.getSerializableExtra("Situacao");


        if(situacao.equals("estaEmpregado")){
            recebeNome.setText(getString(R.string.parabens)+valor);
        }

        if(situacao.equals("estaDesempregado")){
            recebeNome.setText(getString(R.string.Nãosepreocupe)+valor);
        }

        if(situacao.equals("naoProcuraOcupacao")){
            recebeNome.setText(getString(R.string.vidaboa)+valor);
        }

        if(intent.equals("estaEmpregado")){
            recebeNome.setText("Parabéns, "+valor);
        }

        if(intent.equals("estaDesempregado")){
            recebeNome.setText("Não se preocupe, "+valor);
        }

        if(intent.equals("naoProcuraOcupacao")){
            recebeNome.setText("Que vida boa, "+valor);
        }

    btn3 = (Button) findViewById(R.id.btnVolta1);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent3 = new Intent(Info.this, telaCadastro.class);
                startActivity(intent3);
            }
        });

    }


}
