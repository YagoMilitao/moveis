package com.example.kamilla.trabalho;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.view.Menu;

public class telaCadastro extends AppCompatActivity {


    EditText nomeCad;
    Button btn1;
    Button btn2;
    RadioGroup option;
    String opcaoEscolhida="";
    RadioButton emp;
    RadioButton desemp;
    RadioButton ocup;
    Menu menu;
    int it;
    SharedPreferences prefer;



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_cadastro);


        nomeCad = (EditText) findViewById(R.id.nomeCadastro);
        btn1 = (Button) findViewById(R.id.btnDicas);


        btn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent = new Intent(telaCadastro.this, Info.class);
                intent.putExtra("Nome", nomeCad.getText().toString());
                intent.putExtra("Situacao", opcaoEscolhida);
                startActivity(intent);

                finish();

                salvarDados();
            }
        });

        recuperarDados();

        option = (RadioGroup) findViewById(R.id.opcaoCadastro);

        emp = (RadioButton) findViewById(R.id.empregadoRadio);
        emp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opcaoEscolhida = "estaEmpregado";
            }
        });

        desemp = (RadioButton) findViewById(R.id.desempregadoRadio);
        desemp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opcaoEscolhida = "estaDesempregado";
            }
        });

        ocup = (RadioButton) findViewById(R.id.semOcupacaoRadio);
        ocup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opcaoEscolhida = "naoProcuraOcupacao";
            }
        });



        btn2 = (Button) findViewById(R.id.btnLimpa);
        option = (RadioGroup) findViewById(R.id.opcaoCadastro);


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nomeCad.setText("");
                option.clearCheck();
            }
        });
    }

    private void salvarDados() {
        SharedPreferences prefer = getSharedPreferences("PREF", MODE_PRIVATE);
        SharedPreferences.Editor edi = prefer.edit();

        edi.putString("Nome", String.valueOf(nomeCad.getText()));



        edi.apply();
    }

    private void recuperarDados() {
        SharedPreferences prefer = getSharedPreferences("PREF", MODE_PRIVATE);
        nomeCad.setText(prefer.getString("Nome", "não há nada"));


    }

    public boolean onCreateOptionsMenu(Menu menu){

        getMenuInflater().inflate(R.menu.menu_app, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem action_ajuda){
        int it = action_ajuda.getItemId();

        if(it == R.id.action_ajuda){
            Intent intent2 = new Intent(getApplicationContext(), aluno.class);
            startActivity(intent2);
            return true;
        }
        return super.onOptionsItemSelected(action_ajuda);
    }

}

